package edu.fatec.lp2.exercicio1;

public class Contatinho {
	
	private String nome;
	private String celular;
	
	//get e set
	private String getNome() {
		return nome;
	}
	private void setNome(String nome) {
		this.nome = nome;
	}
	private String getCelular() {
		return celular;
	}
	private void setCelular(String celular) {
		this.celular = celular;
	}

}
