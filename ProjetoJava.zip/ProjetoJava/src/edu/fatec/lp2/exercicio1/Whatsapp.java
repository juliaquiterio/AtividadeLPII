package edu.fatec.lp2.exercicio1;

import java.util.ArrayList;

public class Whatsapp extends Contatinho{
	private ArrayList<Contatinho> contatos;
	private ArrayList<Mensagem> mensagens;
	
	
	public Whatsapp(ArrayList<Contatinho> contatos, ArrayList<Mensagem> mensagens) {
		this.contatos = contatos;
		this.mensagens = mensagens;
	}
	
	public void listarContatos(){
		
	}
	public void listarMensagens(){
		
	}	
	

}
