package edu.fatec.lp2.exercicio1;

public class MsgFoto extends Mensagem{
	private int tamanho;
	
	public Mensagem sendMessage(String mensagem) {
		// TODO Auto-generated method stub
		return this;
	}

}
