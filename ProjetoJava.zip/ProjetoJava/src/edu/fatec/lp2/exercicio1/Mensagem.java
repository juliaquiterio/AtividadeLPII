package edu.fatec.lp2.exercicio1;

public abstract class Mensagem{
	private Contatinho destinatario;
	private String horaEnvio;
	private String conteudo;

	
    public String toString(){
        return "";
    }
	
    public String sendMessage(){
    	return sendMessage();
    }
    
    public abstract Mensagem sendMessage(String mensagem);

}
