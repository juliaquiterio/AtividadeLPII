package edu.fatec.lp2.exercicio1;

public class MsgTexto extends Mensagem{
	private int numChar;
	
	public Mensagem sendMessage(String mensagem) {
		// TODO Auto-generated method stub
		return this;
	}
	

}
