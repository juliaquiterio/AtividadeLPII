package edu.fatec.lp2.exercicio1;

public class MsgAudio extends Mensagem{
	private int duracao;
	
	
	public Mensagem sendMessage(String mensagem) {
		// TODO Auto-generated method stub
		return this;
	}


}
