package edu.fatec.lp2.exercicio2;

public abstract class Produto {
	private String nome;
	private String unidade;
	private String descricao;
	private double preco;
	private double descontoMaximo;
	private Supermercado supermercado;
	
	//getters e setters
	private String getNome() {
		return nome;
	}
	private void setNome(String nome) {
		this.nome = nome;
	}
	
	private String getUnidade() {
		return unidade;
	}
	private void setUnidade(String unidade) {
		this.unidade = unidade;
	}
	private String getDescricao() {
		return descricao;
	}
	private void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	private double getDescontoMaximo() {
		return descontoMaximo;
	}
	private void setDescontoMaximo(double descontoMaximo) {
		this.descontoMaximo = descontoMaximo;
	}
	
	private void setPreco(double preco) {
		this.preco = preco;
	}
	
	private Supermercado getSupermercado() {
		return supermercado;
	}
	private void setSupermercado(Supermercado supermercado) {
		this.supermercado = supermercado;
	}
	
	//metodos
	public Produto(Supermercado s) {

    }
	
	public String toString(){
        return "";
    }

	protected abstract int getPreco();
	

}
