package edu.fatec.lp2.exercicio2;

public abstract class ListaCompra {
	private int qtdeMax;
	private ItemCompra[] itensCompra;
	
	public ListaCompra(int qtdeMax) {
        this.qtdeMax = qtdeMax;
        this.itensCompra = new ItemCompra[qtdeMax];
    }
	 
	 //adicionar itens ate o limite
	 public void Incluir(ItemCompra item) {
	        for (int i = 0; i < itensCompra.length; i++) {
	            if (itensCompra[i] == null) {
	                itensCompra[i] = item;
	                return;
	            }
	        }
	        throw new RuntimeException("Limite atingido.");
	    }
	 
	 
	 //calculando preco total da compra 
	 public double calcularPreco() {
	        double precoTotal = 0;
	        for (int i = 0; i < itensCompra.length; i++) {
	            if (itensCompra[i] != null) {
	                precoTotal += itensCompra[i].calcularPreco();
	            }
	        }
	        return precoTotal;
	    }
	private int getQtdeMax() {
		return qtdeMax;
	}
	private void setQtdeMax(int qtdeMax) {
		this.qtdeMax = qtdeMax;
	}
	private ItemCompra[] getItensCompra() {
		return itensCompra;
	}
	private void setItensCompra(ItemCompra[] itensCompra) {
		this.itensCompra = itensCompra;
	}
	 
}
