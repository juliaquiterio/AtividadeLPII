package edu.fatec.lp2.exercicio2;

public abstract class Supermercado {
	private String nome;
}
