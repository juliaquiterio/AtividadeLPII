package edu.fatec.lp2.exercicio2;

public interface Calculavel {
	
	public static double calcularPreco(ItemCompra[] itensCompra) {
        double precoTotal = 0;
        for (int i = 0; i < itensCompra.length; i++) {
            if (itensCompra[i] != null) {
                precoTotal += itensCompra[i].calcularPreco();
            }
        }
        return precoTotal;
    }

}
