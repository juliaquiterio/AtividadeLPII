package edu.fatec.lp2.exercicio2;

public abstract class ItemCompra {
	private int quantidade;
	private Produto produto;
	private double desconto;
	private double descontoMaximo;
	private ItemCompra[] itensCompra;
	
    
	 public double calcularPreco() {
	        double precoTotal = 0;
	        for (int i = 0; i < itensCompra.length; i++) {
	            if (itensCompra[i] != null) {
	                precoTotal += itensCompra[i].calcularPreco();
	            }
	        }
	        return precoTotal;
	    }
	
	private int getQuantidade() {
		return quantidade;
	}


	private void setQuantidade(int quantidade) {
		this.quantidade = quantidade;
	}


	private Produto getProduto() {
		return produto;
	}


	private void setProduto(Produto produto) {
		this.produto = produto;
	}


	private double getDesconto() {
		return desconto;
	}


	//aplicando o desconto maximo
	public void setDesconto(double desconto) {
        if (desconto >= 0 && desconto <= descontoMaximo) {
            this.desconto = desconto;
        } else {
            throw new IllegalArgumentException("ERRO: Desconto não aplicado!");
        }
    }
	
	public double getDescontoMaximo() {
        return descontoMaximo;
    }
	
	public void setDescontoMaximo(double descontoMaximo) {
        this.descontoMaximo = descontoMaximo;
    }

	
}
